import React, { useState, useEffect } from "react";
import API_HOST from '../apiConfig'
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const AddPayment = () => {
  const [creditCardNumber, setCreditCardNumber] = useState("");
  const [amount, setAmount] = useState("");
  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await fetch(`${API_HOST}/add_payment`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ creditCardNumber, amount }),
      });

      const data = await response.json();
      console.log(data);
      handleResponse(data);
      
      
    } catch (error) {
      console.error("Error:", error);
    }
  };
  const handleResponse = (data) => {
    if (data.status == "SUCCESS") {
      toast.success("Payment added successfully", { autoClose: 3000 });
    } else {
      toast.error("Unable to find credit card number", { autoClose: 3000 });
    }
  };
  return (
    <div className="container mt-5">
      <h2 className="mb-4">Add Payment</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="creditCardNumber" className="form-label">Credit Card Number:</label>
          <input
            type="text"
            className="form-control"
            id="creditCardNumber"
            value={creditCardNumber}
            onChange={(e) => setCreditCardNumber(e.target.value)}
            pattern="\d{16}"
            title="Credit card number must be 16 digits"
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="amount" className="form-label">Amount:</label>
          <input
            type="number"
            className="form-control"
            id="amount"
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Add Payment</button>
      </form>

      <ToastContainer position="top-center" autoClose={3000} />
    </div>
  )
};

export default AddPayment;
