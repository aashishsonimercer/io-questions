import React, { useState, useEffect } from 'react'
import TableComponent from '../components/DisplayPaymentTransactions'
import API_HOST from '../apiConfig'
const PaymentHistory = () => {
    const [apiData, setApiData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try { 
        const response = await fetch(`${API_HOST}/show_transactions`);
        const data = await response.json();
        setApiData(data.data);
      } catch (error) {
        console.error("Error fetching data:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="container mt-5">
      <h2>Recent Payment Transactions</h2>
        <div className="container mt-5">
      {loading ? (
        <p>Loading data...</p>
      ) : (
        <TableComponent data={apiData} />
      )}
      </div>
    </div>
  );
}

export default PaymentHistory
