import React from "react";
import API_HOST from '../apiConfig'
import { Link } from "react-router-dom"; // Assuming you are using React Router

const HomePage = () => {
  return (
    <>
    <div className="d-flex justify-content-center align-items-center vh-100">
      <nav className="navbar navbar-expand-lg navbar-light bg-light ">
        <div className="collapse navbar-collapse">
          <ul className="navbar-nav flex-column align-items-center">

            <li className="nav-item">
              <Link to="/register" className="nav-link">
                Register Card
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/transactions" className="nav-link">
                Recent Payment Transaction
              </Link>
            </li>
            <li className="nav-item">
              <Link to="/cards" className="nav-link">
                Saved Cards
              </Link>
            </li>

            <li className="nav-item">
              <Link to="/add_payment" className="nav-link">
                Add Payment
              </Link>
            </li>
          </ul>
        </div>
      </nav>
    </div>
    </>
  );
};

export default HomePage;
