import React, { useState, useEffect } from "react";
import DisplayData from '../components/DisplayData'
import API_HOST from '../apiConfig'
const RegisterCard = () => {
  const [name, setName] = useState("");
  const [pin, setPin] = useState("");
  const [responseData, setResponseData] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const handleSubmit = async (e) => {
    e.preventDefault();

    try { `${API_HOST}/register_card`
      const response = await fetch(`${API_HOST}/register_card`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, pin }),
      });

      const data = await response.json();
      console.log(data)
      setResponseData(data.data);
      setShowModal(true);
    } catch (error) {
      console.error("Error:", error);
    }
  };
  const closeModal = () => {
    setShowModal(false);
  };
  return (
    <div className="container mt-5">
      <h2 className="mb-4">Register Card</h2>
      <form onSubmit={handleSubmit}>
        <div className="mb-3">
          <label htmlFor="name" className="form-label">Name:</label>
          <input
            type="text"
            className="form-control"
            id="name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
          />
        </div>
        <div className="mb-3">
          <label htmlFor="pin" className="form-label">PIN:</label>
          <input
            type="password"
            className="form-control"
            id="pin"
            value={pin}
            onChange={(e) => setPin(e.target.value)}
            minLength="6"
            maxLength="6"
            pattern="\d+"
            title="PIN should be numbers only"
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Generate</button>
      </form>

      {responseData && (
        <DisplayData show={showModal} onHide={closeModal} data={responseData} />
      )}
    </div>
  );
};

export default RegisterCard;
