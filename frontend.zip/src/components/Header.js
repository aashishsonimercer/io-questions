import React from "react";

const header = () => {
  return (
    <div className="app-header">
      <h1>Card Payment </h1>
    </div>
  );
};

export default header;
