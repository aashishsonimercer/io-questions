import React from 'react';
import { Modal, Button, Table } from 'react-bootstrap';

const DisplayData = ({ show, onHide, data }) => {
    const getTableRows = () => {
        if (!data || data.length === 0) {
            return null
            
        }
    
        const fields = Object.keys(data[0]);
    
        return data.map((item, index) => (
          <tr key={index}>
            {fields.map((field, subIndex) => (
              <td key={subIndex}>{item[field]}</td>
            ))}
          </tr>
        ));
      };
      return (
        <Modal show={show} onHide={onHide} size="lg">
          <Modal.Header closeButton>
            <Modal.Title>Data Table</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            {data.lenght }
            <Table striped bordered hover>
              <thead>
                <tr>
                  {data && data.length > 0 && Object.keys(data[0]).map((field, index) => (
                    <th key={index}>{field}</th>
                  ))}
                </tr>
              </thead>
              <tbody>{getTableRows()}</tbody>
            </Table>
          </Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={onHide}>
              Close
            </Button>
          </Modal.Footer>
        </Modal>
      );
    };
    
    export default DisplayData;