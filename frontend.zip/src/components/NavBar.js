import React from 'react'
import Container from 'react-bootstrap/Container';
import Nav from 'react-bootstrap/Nav';
import Navbar from 'react-bootstrap/Navbar';
import { Link } from "react-router-dom";
const NavBar = () => {
  return (
    <Navbar bg="dark" variant="dark">
      <Container>
        <Link to="/" className="navbar-brand">Card Payment</Link>
        <Nav className="me-auto">
          <Link to="/register" className="nav-link">Register Card</Link>
          <Link to="/transactions" className="nav-link">Recent Payment Transaction</Link>
          <Link to="/cards" className="nav-link">Saved Cards</Link>
          <Link to="/add_payment" className="nav-link">Add Payment</Link>
        </Nav>
      </Container>
    </Navbar>
    
  )
}

export default NavBar
