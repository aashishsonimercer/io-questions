import logo from './logo.svg';
import './App.css';
import { useEffect } from "react";
import RegisterCard from './pages/RegisterCard'
import PaymentHistory from './pages/PaymentHistory'
import SavedCards from './pages/SavedCards'
import AddPayment from './pages/AddPayment'
import HomePage from './pages/HomePage'
import NavBar from './components/NavBar';
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";
function App() {

  return (
    <BrowserRouter>
    {/* <Navbar title="Siidhi Vinayaka" /> */}
    <NavBar/>
    <Routes>
    <Route path="/" element={<HomePage/>} />
    <Route path="/register" element={<RegisterCard/>} />
    <Route path="/transactions" element={<PaymentHistory/>} />
    <Route path="/cards" element={<SavedCards/>} />
    <Route path="/add_payment" element={<AddPayment/>} />
    </Routes>
  </BrowserRouter>
  );
}

export default App;
