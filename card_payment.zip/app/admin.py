from django.contrib import admin

# Register your models here.

from .models import Card, Payment

admin.site.register(Card)
admin.site.register(Payment)