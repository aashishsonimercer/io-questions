from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .serializer import CardModelSerializer, PaymentModelSerializer, PaymentModelGetSerializer
from django.db.models import Q
from .models import Card, Payment
from random import randint
from datetime import date, datetime


class CardCreateView(APIView):
    def post(self, request):
        data = {}
        for key in request.data.keys():
            data[key] = request.data[key]
        card_number = str(randint(1,9))
        for _ in range(15):
            card_number += str(randint(0,9))
        today = date.today()
        expiry_date = f'{today.month}/{today.year+5}'
        cvv = ''
        for _ in range(3):
            cvv += str(randint(0,9))
        data['number'] = card_number
        data['expiry'] = expiry_date
        data['cvv'] = cvv
        serializer = CardModelSerializer(data = data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status = status.HTTP_201_CREATED)
        return Response(serializer.errors, status = status.HTTP_400_BAD_REQUEST)

class CardVerifyView(APIView):
    def post(self, request):
        data = request.data
        try:
            obj = Card.objects.get(Q(name = data['name']), 
                                   Q(number = data['number']),
                                   Q(expiry = data['expiry']),
                                   Q(cvv = data['cvv']))
        except Card.DoesNotExist:
            return Response(status = status.HTTP_404_NOT_FOUND)
        except:
            return Response(status = status.HTTP_400_BAD_REQUEST)
        return Response(status = status.HTTP_202_ACCEPTED)
    
class CardPayView(APIView):
    def post(self, request):
        data = {}
        for key in request.data.keys():
            data[key] = request.data[key]
        data['date'] = datetime.now()
        
        serializer = PaymentModelSerializer(data = data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status = status.HTTP_201_CREATED)
        return Response(serializer.errors, status = status.HTTP_400_BAD_REQUEST)
    
class CardPaymentView(APIView):
    def get(self, request):
        payments = Payment.objects.all()
        serializer = PaymentModelGetSerializer(payments, many = True)
        return Response(serializer.data, status = status.HTTP_200_OK)   