from django.urls import path
from . import views

from django.urls import path, include
from rest_framework import routers
from app.service_views.card_view import CardsView
from app.service_views.payment_view import PaymentView
from app.service_views.register_card import RegisterCardView
from app.service_views.saved_cards import SavedCardsView
from app.service_views.add_payment import AddPaymentView
from app.service_views.show_transactions import ShowTransactionsView

router = routers.DefaultRouter()

router.register('cards', CardsView)
router.register('payment', PaymentView)

urlpatterns = [
    path('', include(router.urls)),
    path('register_card', RegisterCardView.as_view({'post': 'list'})),
    path('saved_cards', SavedCardsView.as_view({'post': 'list'})),
    path('add_payment', AddPaymentView.as_view({'post': 'list'})),
    path('show_transactions', ShowTransactionsView.as_view())
]
