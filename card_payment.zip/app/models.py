from django.db import models
from uuid import uuid4

class ResponseChoices(models.TextChoices):
    SUCCESS = 'SUCCESS'
    FAILED = 'FAILED'

class Card(models.Model):
    id = models.AutoField(auto_created=True, primary_key=True)
    name = models.CharField(max_length=30, blank=True, null=True)
    number = models.CharField(max_length=16, unique=True)
    expiry = models.CharField(max_length=10, blank=True, null=True)
    cvv = models.IntegerField(blank=True, null=True)
    pin = models.IntegerField(blank=True, null=True)
    balance = models.IntegerField(default=0, blank=True, null=True)


class Payment(models.Model):
    id = models.AutoField(auto_created=True, primary_key=True)
    card = models.ForeignKey(Card, on_delete=models.CASCADE, blank=True, null=True)
    date = models.DateTimeField(blank=True, null=True)
    amount = models.FloatField(blank=True, null=True)