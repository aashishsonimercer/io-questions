from rest_framework import serializers
from .models import Card, Payment


class CardModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Card
        fields = "__all__"
        
class PaymentModelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Payment
        fields = "__all__"
        
class PaymentModelGetSerializer(serializers.ModelSerializer):
    card_name = serializers.SerializerMethodField('get_card_name')
    card_number = serializers.SerializerMethodField('get_card_number')
    class Meta:
        model = Payment
        fields = ('card_name', 'amount', 'date', 'card_number')
        
    def get_card_name(self, payment_object):
        name = Card.objects.get(id = payment_object.card_id).name
        return name
    
    def get_card_number(self, payment_object):
        number = Card.objects.get(id = payment_object.card_id).number
        cardnum = 'XXXXXXXXXXXX'
        cardnum += number[-4:]
        return cardnum