# app/clientManager.py

from flask import jsonify, request
from app.database_manager import DatabaseManager
from app.models import Client

db_manager = DatabaseManager()


class ClientManager:
    def create_client(self, name, email, phone, address):
        # Create a new client
        new_client = Client(name=name, email=email, phone=phone, address=address)

        # Add the client to the database
        db_manager.session.add(new_client)
        db_manager.session.commit()

        return new_client

    def getAllClients(self):

        # Add Implementation to fetch all clients from the database.
        clients = Client.query.all()
        client_list = []
        for client in clients:
            client_list.append({
                "id": client.id,
                "name": client.name,
                "email": client.email,
                "phone": client.phone,
                "address": client.address
            })
        return jsonify(client_list)

    def get_client(self, client_id):
        # Add Implementation to fetch details of a specific client based on the provided client ID.
        client = Client.query.get(client_id)
        if client:
            client_details = {
                "id": client.id,
                "name": client.name,
                "email": client.email,
                "phone": client.phone,
                "address": client.address
            }
            return jsonify(client_details)
        else:
            return jsonify({"error": "Client not found"})


def add_client(self, name, emailID, phone, address):
    # Check if the client with the same email already exists with same email id, if yes then retun error "Client with the same email already exists". else add implementation to add a new client to the database.
    existing_client = Client.query.filter_by(email=email).first()
    if existing_client:
        return jsonify({"error": "Client with the same email already exists"})

    # Add a new client to the database

    new_client = Client(name=name, email=email, phone=phone, address=address)

    # Add the client to the database
    db_manager.session.add(new_client)
    db_manager.session.commit()

    return new_client
