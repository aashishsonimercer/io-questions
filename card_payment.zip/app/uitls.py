def RESPONSE(msg="",status="",data={}):
    return {
        "msg": msg,
        "status": status,
        "data": data
    }

SECRET_CODE_PASSWORD= 'secretchahat'