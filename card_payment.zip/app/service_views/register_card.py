from rest_framework import viewsets, status
from rest_framework.response import Response
from app.models import Card, Payment, ResponseChoices
from datetime import datetime
from app.uitls import RESPONSE
from rest_framework.permissions import IsAuthenticated
from drf_spectacular.utils import extend_schema
import random
from datetime import datetime, timedelta
from app.serializer import CardModelSerializer

class RegisterCardView(viewsets.ModelViewSet):
    # permission_classes = [IsAuthenticated]

    def generate_random_cvv(self):
        # Generate a random 3-digit CVV
        return str(random.randint(100, 999))

    def generate_random_16_digit_number(self):
        # Generate a random 16-digit number
        return ''.join(str(random.randint(0, 9)) for _ in range(16))

    def generate_random_expiry_date(self):
        # Generate a random month and year
        current_year = datetime.now().year
        random_year = random.randint(current_year % 100, current_year % 100 + 10)  # Card expires in the next 10 years
        random_month = random.randint(1, 12)

        # Create a date object with the first day of the selected month and year
        expiry_date = datetime(random_year, random_month, 1)

        # Add a random number of days (up to 28) to simulate a day within the month
        expiry_date += timedelta(days=random.randint(0, 28))

        # Format the expiry date as MM/YY
        formatted_expiry_date = expiry_date.strftime('%m/%y')

        return formatted_expiry_date

    def list(self, request, *args, **kwargs):
        name = request.data['name']
        pin = request.data['pin']
        try:
            card_no = self.generate_random_16_digit_number()
            expiry = self.generate_random_expiry_date()
            cvv = self.generate_random_cvv()
            card_obj = Card(name=name, pin=pin, number=card_no, expiry=expiry, cvv=cvv)
            card_obj.save()
            print(card_obj)
            msg = "Added card successfully"
            serializer = CardModelSerializer(instance=card_obj)
            return Response(RESPONSE(msg=msg, status=ResponseChoices.SUCCESS, data=[serializer.data]), status=status.HTTP_200_OK)
        except Exception as e:
            msg = f'Error Occured: {e}'
            return Response(RESPONSE(msg=msg, status=ResponseChoices.FAILED), status=status.HTTP_404_NOT_FOUND)
