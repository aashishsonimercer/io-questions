from rest_framework import viewsets
from rest_framework import views, status
from app.models import Card, Payment
from app.serializer import PaymentModelSerializer, CardModelSerializer
from rest_framework.response import Response
from app.models import Card, Payment, ResponseChoices
from app.uitls import RESPONSE

class ShowTransactionsView(views.APIView):
    @staticmethod
    def get(request, *args, **kwargs):
        try:
            queryset = Payment.objects.all()
            serializer = PaymentModelSerializer(queryset, many=True)
            msg="Showing transactions"
            for data in serializer.data:
                payment_id = data["id"]
                card_id = data["card"]
                card_instance = Card.objects.get(pk=card_id)
                card_serializer = CardModelSerializer(instance = card_instance)
                del data["card"]
                data.update(card_serializer.data)
                data["id"] = payment_id
            return Response(RESPONSE(msg=msg, status=ResponseChoices.SUCCESS, data=serializer.data),
                            status=status.HTTP_200_OK)
        except Exception as e:
            msg = f'Error Occured: {e}'
            return Response(RESPONSE(msg=msg, status=ResponseChoices.FAILED), status=status.HTTP_404_NOT_FOUND)


    # def paginate_queryset(self, queryset):
    #     if self.paginator and self.request.query_params.get(self.paginator.page_query_param, None) is None:
    #         return None
    #     return super().paginate_queryset(queryset)
