from rest_framework import viewsets, status
from rest_framework.response import Response
from app.models import Card, Payment, ResponseChoices
from datetime import datetime
from app.uitls import RESPONSE
from rest_framework.permissions import IsAuthenticated
from drf_spectacular.utils import extend_schema
import random
from datetime import datetime, timedelta
from app.serializer import CardModelSerializer, PaymentModelSerializer


class SavedCardsView(viewsets.ModelViewSet):
    # permission_classes = [IsAuthenticated]
    def list(self, request, *args, **kwargs):
        name = request.data['name']
        try:
            results = Card.objects.filter(name__contains=name)
            serializer = CardModelSerializer(results, many=True)
            msg = "Showing saved cards for name contains {}".format(name)
            return Response(RESPONSE(msg=msg, status=ResponseChoices.SUCCESS, data=serializer.data),
                            status=status.HTTP_200_OK)
        except Exception as e:
            msg = f'Error Occured: {e}'
            return Response(RESPONSE(msg=msg, status=ResponseChoices.FAILED), status=status.HTTP_404_NOT_FOUND)
