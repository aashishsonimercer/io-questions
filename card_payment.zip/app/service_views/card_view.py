from rest_framework import viewsets
from app.models import Card, Payment
from app.serializer import PaymentModelSerializer, CardModelSerializer
from rest_framework.response import Response

class CardsView(viewsets.ModelViewSet):
    queryset = Card.objects.all()
    serializer_class = CardModelSerializer

    # def paginate_queryset(self, queryset):
    #     if self.paginator and self.request.query_params.get(self.paginator.page_query_param, None) is None:
    #         return None
    #     return super().paginate_queryset(queryset)
