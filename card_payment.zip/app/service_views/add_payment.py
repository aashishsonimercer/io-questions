from rest_framework import viewsets, status
from rest_framework.response import Response
from app.models import Card, Payment, ResponseChoices
from datetime import datetime
from app.uitls import RESPONSE
from rest_framework.permissions import IsAuthenticated
from drf_spectacular.utils import extend_schema
import random
from datetime import datetime, timedelta
from app.serializer import CardModelSerializer, PaymentModelSerializer

class AddPaymentView(viewsets.ModelViewSet):
    # permission_classes = [IsAuthenticated]
    def list(self, request, *args, **kwargs):
        card_no = request.data['creditCardNumber']
        amount = int(request.data['amount'])
        try:
            card_obj_queryset = Card.objects.filter(number=card_no)
            if len(card_obj_queryset)!=0:
                card_obj= card_obj_queryset[0]
                card_obj.balance = card_obj.balance + amount
                card_obj.save()

                #adding in transactions also
                payment_obj = Payment(card=card_obj, date=datetime.now(), amount=amount)
                payment_obj.save()
                serializer = CardModelSerializer(instance=card_obj)
                msg = "Added amount successfully and add transactions in payments"
                return Response(RESPONSE(msg=msg, status=ResponseChoices.SUCCESS, data=serializer.data), status=status.HTTP_200_OK)
            else :
                msg = "No Credit Card is present with given number"
                return Response(RESPONSE(msg=msg, status=ResponseChoices.FAILED, data={}),
                                status=status.HTTP_200_OK)
        except Exception as e:
            msg = f'Error Occured: {e}'
            return Response(RESPONSE(msg=msg, status=ResponseChoices.FAILED), status=status.HTTP_404_NOT_FOUND)
